import 'package:flutter/material.dart';











class HirePage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.orange,



    );
  }
}


