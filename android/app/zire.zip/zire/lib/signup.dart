import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:zire/config.dart';
import 'Home_widget.dart';
import 'package:zire/login.dart';
import 'package:zire/main.dart';
import 'package:zire/progressdialog.dart';
import 'package:zire/customTextField.dart';
import 'package:zire/errorDialog.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';



class Signup extends StatefulWidget {
  static const String idScreen = "register";
  @override
  _SignupState createState() => _SignupState();
}

class _SignupState extends State<Signup> {


  final TextEditingController nameTextEditingController = TextEditingController();
  final TextEditingController emailTextEditingController = TextEditingController();
  final TextEditingController phoneTextEditingController = TextEditingController();
  final TextEditingController passwordTextEditingController = TextEditingController();
  final TextEditingController cpasswordTextEditingController = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String userImageUrl = "";
  File _imageFile;

  @override
  Widget build(BuildContext context) {
    double _screenWidth = MediaQuery
        .of(context)
        .size
        .width,
        _screenHeight = MediaQuery
            .of(context)
            .size
            .height;
    return Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Container(
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("images/back3.png"), fit: BoxFit.fill),
                color: Colors.white
            ),

            child: Center(
              child: Column(
                children: <Widget>[

                  SizedBox(height: 1.0,),
                  Text(
                    "create account",
                    style: TextStyle(fontSize: 24.0),
                    textAlign: TextAlign.center,
                  ),
                  InkWell(
                    onTap: _selectimage,
                    child: CircleAvatar(
                      radius: _screenWidth * 0.15,
                      backgroundColor: Colors.white,
                      backgroundImage: _imageFile == null ? null : FileImage(
                          _imageFile),
                      child: _imageFile == null
                          ? Icon(Icons.add_a_photo, size: _screenWidth * 0.15,
                        color: Colors.grey,) : null,
                    ),
                  ),

                  SizedBox(height: 1.0,),
                  Form(
                      key: formKey,
                      child: Column(
                        children: [

                          CustomTextField(
                            controller: nameTextEditingController,
                            data: Icons.person,
                            hintText: "name",
                            isObscure: false,),
                          CustomTextField(
                            controller: emailTextEditingController,
                            data: Icons.person,
                            hintText: "name",
                            isObscure: false,),
                          CustomTextField(
                            controller: phoneTextEditingController,
                            data: Icons.person,
                            hintText: "name",
                            isObscure: false,),
                          CustomTextField(
                            controller: passwordTextEditingController,
                            data: Icons.person,
                            hintText: "name",
                            isObscure: true,
                          ),
                          CustomTextField(
                            controller: cpasswordTextEditingController,
                            data: Icons.person,
                            hintText: "name",
                            isObscure: false,),

                        ],

                      )
                  ),

                  RaisedButton(
                    color: Colors.yellow,
                    textColor: Colors.white,
                    child: Container(
                      height: 50.0,
                      child: Center(
                        child: Text(
                          "Create Account",
                          style: TextStyle(fontSize: 18.0),
                        ),
                      ),
                    ),
                    shape: new RoundedRectangleBorder(
                      borderRadius: new BorderRadius.circular(24.0),
                    ),
                    onPressed: () {
                      uploadAndSaveImage();
                    },


                  ),

                  FlatButton(
                    onPressed: () {
                      Navigator.pushNamedAndRemoveUntil(
                          context, Login.idScreen, (route) => false);
                    },
                    child: Text("Already have an account? login Here"),
                  ),
                ],
              ),
            ),
          ),
        ));
  }

  Future<void> _selectimage() async
  {
    _imageFile = await ImagePicker.pickImage(source: ImageSource.gallery);
  }

  Future<void> uploadAndSaveImage() async
  {
    if (_imageFile == null) {
      showDialog(
          context: context,
          builder: (c) {
            return ErrorAlertDialog(message: "please select an image file",);
          }
      );
    }

    else {
      passwordTextEditingController.text == cpasswordTextEditingController.text
          ? emailTextEditingController.text.isNotEmpty &&
          passwordTextEditingController.text.isNotEmpty &&
          cpasswordTextEditingController.text.isNotEmpty &&
          nameTextEditingController.text.isNotEmpty
          ? uploadToStorage()

          : displayDialog("Please fill up the registration complete form..")

          : displayDialog("Password do not match");
    }
  }

  displayDialog(String msg) {
    showDialog(
        context: context,
        builder: (c) {
          return ErrorAlertDialog(message: msg,);
        }
    );
  }

  uploadToStorage() async
  {
    showDialog(
        context: context,
        builder: (c) {
          return ProgressDialog(message: " loading.. please wait...",);
        }
    );
    FirebaseStorage storage = FirebaseStorage.instance;
    String imageFileName = DateTime
        .now()
        .microsecondsSinceEpoch
        .toString();


    Reference ref = storage.ref().child("imageFileName" + DateTime.now().toString());
    UploadTask uploadTask = ref.putFile(_imageFile);
    uploadTask.whenComplete(() async { userImageUrl = await ref.getDownloadURL();


      registerNewUser();
    });
  }

  FirebaseAuth _auth = FirebaseAuth.instance;

  void registerNewUser() async
  {
    FirebaseUser firebaseUser;
    await _auth.createUserWithEmailAndPassword(
      email: emailTextEditingController.text.trim(),
      password: passwordTextEditingController.text.trim(),).then((auth) {
      firebaseUser = auth.user;
    }).catchError((errMsg) {
      Navigator.pop(context);

      displayToastMessage("Error: " + errMsg.toString(), context);
    });

    if (firebaseUser != null) {
      saveUserInfoToFirestore(firebaseUser);
      displayToastMessage(
          "Congratulation, your account has been created.", context);
      Navigator.pushNamedAndRemoveUntil(
          context, Home.idScreen, (route) => false);
    }
    else {
      Navigator.pop(context);

      displayToastMessage("new user account has not been created  ", context);
    }
  }

  displayToastMessage(String message, BuildContext context) {
    Fluttertoast.showToast(msg: message);
  }

  Future saveUserInfoToFirestore(FirebaseUser fUser) async
  {
    Firestore.instance.collection("user").document(fUser.uid).setData({
      "uid": fUser.uid,
      "email": fUser.email,
      "name": nameTextEditingController.text.trim(),
      "phone": phoneTextEditingController.text.trim(),
      "url": userImageUrl,
    });

    await Zireapp.sharedPreferences.setString("uid", fUser.uid);
    await Zireapp.sharedPreferences.setString(Zireapp.userEmail, fUser.email);
    await Zireapp.sharedPreferences.setString(
        Zireapp.userAvatarUrl, userImageUrl);
    await Zireapp.sharedPreferences.setString(
        Zireapp.userName, nameTextEditingController.text);
    await Zireapp.sharedPreferences.setString(
        Zireapp.userPhone, phoneTextEditingController.text);
  }
}