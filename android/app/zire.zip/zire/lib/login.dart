
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:zire/errorDialog.dart';
import 'package:zire/main.dart';
import 'package:animated_button/animated_button.dart';
import 'package:zire/Home_widget.dart';
import 'package:zire/progressdialog.dart';
import 'package:zire/signup.dart';
import 'package:zire/customTextField.dart';
import 'package:zire/config.dart';


class Login extends StatefulWidget {
  static const String idScreen = "login";
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {


  final TextEditingController emailTextEditingController = TextEditingController();
  final TextEditingController passwordTextEditingController = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Column(
                  children: [
                    SizedBox(height: 50.0,),
                    Image(
                      image: AssetImage("images/back2.png"),
                      width: 250.0,
                      height: 250.0,
                      alignment: Alignment.center,
                    ),
                    SizedBox(height: 10.0,),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        "Hello",
                        style: TextStyle(fontSize: 24.0),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        children: <Widget>[
                          SizedBox(height: 1.0,),
                          CustomTextField(
                            controller: emailTextEditingController,
                            data: Icons.person,
                            hintText: "name",
                            isObscure: false,),
                          CustomTextField(
                            controller: passwordTextEditingController,
                            data: Icons.person,
                            hintText: "name",
                            isObscure: true,
                          ),


                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: AnimatedButton(
                                    enabled: true,
                                    height: 50,
                                    width: 130,
                                    color: Colors.blue,
                                    onPressed: () {
                                      if (!emailTextEditingController.text
                                          .contains("@")) {
                                        displayToastMessage(
                                            "Email address is not valid",
                                            context);
                                      }
                                      else
                                      if (passwordTextEditingController.text
                                          .isEmpty) {
                                        displayToastMessage(
                                            "password is mandatory ",
                                            context);
                                      }
                                      else {
                                        loginAndAuthenticateUser(context);
                                      }
                                    },


                                    child: Text(
                                      "Login",
                                      style: TextStyle(fontSize: 18.0),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text("need help",
                                    style: TextStyle(
                                        color: Colors.red,
                                        fontWeight: FontWeight.w600
                                    ),),
                                )

                              ]),


                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: FlatButton(
                              onPressed: () {
                                Navigator.pushNamedAndRemoveUntil(context,
                                    Signup.idScreen, (route) => false);
                              },
                              child: Text(
                                  "Do not have an account? Register Here"),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ]),
            )));
  }

  displayToastMessage(String message, BuildContext context) {
    Fluttertoast.showToast(msg: message);
  }

  void loginAndAuthenticateUser(BuildContext context) async
  {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return ProgressDialog(message: "loading, Please wait....",);
        });


    FirebaseAuth _auth = FirebaseAuth.instance;


    {
      FirebaseUser firebaseUser;
      await _auth.signInWithEmailAndPassword(
        email: emailTextEditingController.text.trim(),
        password: passwordTextEditingController.text.trim(),).then((authUser) {
        firebaseUser = authUser.user;
      }).catchError((errMsg) {
        Navigator.pop(context);
        displayToastMessage("Error: " + errMsg.toString(), context);
      });


      if (firebaseUser != null) {
        readData(firebaseUser).then((value) => null);
      }
    }
  }

  Future readData(FirebaseUser fUser) async
  {
    Firestore.instance.collection("users").document(fUser.uid).get().then((
        dataSnapshot)
    async {
      await Zireapp.sharedPreferences.setString(
          "uid", dataSnapshot.get(Zireapp.userUID));
      await Zireapp.sharedPreferences.setString(
          Zireapp.userEmail, dataSnapshot.get(Zireapp.userEmail));
      await Zireapp.sharedPreferences.setString(
          Zireapp.userName, dataSnapshot.get(Zireapp.userName));
      await Zireapp.sharedPreferences.setString(
          Zireapp.userAvatarUrl, dataSnapshot.get(Zireapp.userAvatarUrl));
    } );
  }
}