import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:zire/config.dart';
import 'package:zire/hire_cat.dart';
import 'package:zire/welcome.dart';
import 'Home_widget.dart';
import 'package:zire/login.dart';
import 'package:zire/signup.dart';
import 'package:shared_preferences/shared_preferences.dart';


void main() async
{
  WidgetsFlutterBinding.ensureInitialized();
  Zireapp.auth = FirebaseAuth.instance;
  Zireapp.sharedPreferences = await SharedPreferences.getInstance();
  Zireapp.firestore = Firestore.instance;

  runApp(MyApp());
}
DatabaseReference usersRef = FirebaseDatabase.instance.reference().child("users");
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "ZIRE",
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),

      initialRoute: FirebaseAuth.instance.currentUser == null ? Welcome.idScreen : Home.idScreen,
      routes:
      {
        Welcome.idScreen:(context) => Welcome(),
        Signup.idScreen: (context) => Signup(),
        Login.idScreen: (context) => Login(),
        Home.idScreen: (context) => Home(),
      },
    );
  }
}